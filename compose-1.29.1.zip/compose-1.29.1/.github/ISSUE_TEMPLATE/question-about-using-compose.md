---
name: Question about using Compose
about: This is not the appropriate channel
title: ''
labels: kind/question
assignees: ''

---

Please post on our forums: https://forums.docker.com for questions about using `docker-compose`.

Posts that are not a bug report or a feature/enhancement request will not be addressed on this issue tracker.
