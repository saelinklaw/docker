# The docs have been moved!

The documentation for Compose has been merged into
[the general documentation repo](https://github.com/docker/docker.github.io).

The docs for Compose are now here:
https://github.com/docker/docker.github.io/tree/master/compose

Please submit pull requests for unreleased features/changes on the `master` branch (https://github.com/docker/docker.github.io/tree/master), please prefix the PR title with `[WIP]` to indicate that it relates to an unreleased change.

If you submit a PR to this codebase that has a docs impact, create a second docs PR on `docker.github.io`. Use the docs PR template provided.

As always, the docs remain open-source and we appreciate your feedback and
pull requests!
